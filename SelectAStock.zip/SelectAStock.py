
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import datetime  # For datetime objects
import os.path, time  # To manage paths
from os import path
import sys  # To find out the script name (in argv[0])
from decimal import Decimal
# Import the backtrader platform
import backtrader as bt    

import tkinter as tk
from tkinter import *
from tkinter import ttk
from pathlib import Path
import json
import matplotlib
import matplotlib.pyplot as plt
from enum import Enum
import csv
import pandas
import math
matplotlib.use('QT5Agg')


class stockDataSource(Enum):
    CHECKHISTORY = 1
    PORTFOLIOFILE = 2

class thisStockBought(Enum):
    NO=0
    YES=1


class TestStrategy(bt.Strategy):
    
    import matplotlib
   # import matplotlib.pyplot as plt
    global closeList
    
    
    def log(self, txt, dt=None):
        ''' Logging function for this strategy'''
        dt = dt or self.datas[0].datetime.date(0)
       # print('%s, %s' % (dt.isoformat(), txt))
        print('%s, %s' % (dt.strftime("%m/%d/%Y"), txt))
        global stockInfo
       # global closeList
        stockInfo+='%s, %s' % (dt.strftime("%m/%d/%Y"), txt) + "\n"
        #shortDate=dt.strftime("%b-%d-%y")
        shortDate=dt.strftime("%m/%d/%Y")
        if not shortDate in closeList:
         closeList.append(shortDate)

        
    def __init__(self):
        # Keep a reference to the "close" line in the data[0] dataseries
        self.dataclose = self.datas[0].close
       
       # self.datahigh = self.datas[0].high
        # To keep track of pending orders
        self.order = None  
 
    def notify_order(self, order):
        global balance
        if order.status in [order.Submitted, order.Accepted]:
            # Buy/Sell order submitted/accepted to/by broker - Nothing to do
            return

        # Check if an order has been completed
        # Attention: broker could reject order if not enough cash
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log('BUY EXECUTED, %.2f' % order.executed.price)
                balance -= order.executed.price
                self.log('CURRENT BALANCE: %.2f' % balance)
            elif order.issell():
                self.log('SELL EXECUTED, %.2f' % order.executed.price)
                balance += order.executed.price
                self.log('CURRENT BALANCE: %.2f' % balance)
            self.bar_executed = len(self)

        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')

        # Write down: no pending order
        self.order = None  
 

    def notify_trade(self, trade):
        if not trade.isclosed:
            return

        self.log('OPERATION PROFIT, GROSS %.2f, NET %.2f' %
                 (trade.pnl, trade.pnlcomm))
       
        
    def next(self):
        # Simply log the closing price of the series from the reference
        self.log('Close, %.2f' % self.dataclose[0])
       
        global currentStep
        global baseline
        global Gt
        global oldReward
        global Return
        global reweighting
        global balance
        global closeValues
        global gotStockDataFrom
        global lblBuy
        global entBuyAmount
        global buyAmount
        global lastClosingPrice
        global buyingChoice
        global path
        global stockSymbolString
        global numberOfShares
        global netWorth
        global profit
        global lastClosingPrice
        global tradingAmount
        global currentPrice
        global tradingAmount
        global profitValues
        global dropCount
        global wasBought
        readCurrentPrice=0
        readTradingAmount=0
        readNetWorth=0
        readProfit=0
        readNumberOfShares=0
        todaysDate=datetime.datetime.now()
       # global portfolioFile
        stockSymbolString=txtStockSymbol.get()
        currentPrice=self.dataclose[0]
        portFile='./portfolio/' + stockSymbolString + '.csv'
        profitValues=[]
        print ("PROFIT VALUES:")
        print (profitValues)
        print(wasBought.name)
        if (os.path.exists('./portfolio/' + stockSymbolString + '.csv') and str(gotStockDataFrom.name) == 'PORTFOLIOFILE'):
              modTime=time.strftime('%m/%d/%Y', time.localtime(os.path.getmtime(portFile)))
              print (modTime)
              print (todaysDate.strftime('%m/%d/%Y'))         
              print('./portfolio/' + stockSymbolString + '.csv')
              print( os.path.exists('./portfolio/' + stockSymbolString + '.csv'))
              print (stockSymbolString)
              print ("FOR STOCK SYMBOL: " + stockSymbolString)
              print ("AMOUNT OF PURCHASE: " + str( tradingAmount))
              print ("CLOSING PRICE: " + str(currentPrice))
             # numberOfShares=float(tradingAmount)/float(currentPrice)
             # numberOfShare="%.2f" % numberOfShares
            #  print (numberOfShares)
              print ("YOU BOUGHT " + str(numberOfShares))
              #balance -= float(tradingAmount)
              print ("YOUR BALANCE: " + str(balance))
              print ("BALANCE: " + str(type(balance)) + " NUMBER OF SHARES: " + str(type(numberOfShares)) + " CURRENT PRICE: " + str(type(currentPrice)))
              netWorth=float(balance) + float(numberOfShares) * float(currentPrice)
              netWorth=round(netWorth,2)
              print ("NET WORTH: " + str(netWorth))
              profit=netWorth-float(balance)
              profit=round(profit,2)
              print ("PROFIT: " + str(profit))
              portfolioRows=""
              portfolioFileName=stockSymbolString + ".csv"
             # currentPortfolioDate=str(currentPortfolioDate)[:10] 
              todaysDate=str(todaysDate)[:10]
              print ('CURRENT PORTFOLIO DATE: ' + str(currentPortfolioDate) + " TODAYS DATE: " + str(todaysDate))        
              csvRows=[stockSymbolString, self.datas[0].datetime.date(0), balance,'HOLD',numberOfShares,currentPrice,tradingAmount,netWorth,profit]      
              profitValues.append(profit)
              with open('./portfolio/' + portfolioFileName, 'a') as portfolioFile:
                     csvWriter=csv.writer(portfolioFile)
                     csvWriter.writerow(csvRows) 

       
        txtPortfolio.delete(0,END)
        txtPortfolio.insert(END,float(balance))
        stockSymbolString=txtStockSymbol.get().upper()
        todaysDate=datetime.datetime.now().strftime('%m/%d/%Y')
        finalPortfolioValue=float(txtPortfolio.get())
        epsilon=0.4
        rClip=0
        gamma=0.7
        lastClosingPrice=self.dataclose[0]
       # print ("SOURCE: " + gotStockDataFrom.name)
       # global closeValues
       # global closeList
        global plt
        currentStep += 1
        delayModifier=lastClosingPrice/365
        reward=float(balance) * float(delayModifier)
       # print ("TRACING REWARD VALUE: %.2f" % reward)
        closeValues.append(self.dataclose[0])
        if currentStep == 1:
            if baseline==0:
                baseline=reward
            Return=reward
            #print ("RETURN:" + str(Return))
        else:
            try:
               # print ("CALCULAING BASELINE")
               # print ("CURRENT STEP: " + str(currentStep))
                if currentStep < 5:
                    Return += reward * (gamma ** currentStep) #DISCOUNTED SUM
                    Gt=Return
                    advantageEst=Return/(currentStep) 
                    if currentStep==4: #DEFINE THE BASELINE
                        baseline=Return/4
                       
                else:
                 #   print ("BASELINE: %.2f" % baseline)
                    Return += reward
                   # print ("RETURN:" + str(Return))
                    Gt=Return
                   # baseline=Gt/currentStep
                    advantageEst= Return/(currentStep) - baseline
                    if oldReward == 0:
                        oldReward=reward                
                    else: #CALCULATE THE REWEIGHTING FACTOR
                        #if reward < oldReward:
                           # self.stockWarning="COULD WARN OF DROP IN STOCK"
                        reweighting=reward/oldReward
                    oldReward=reward #SAVE THE CURRENT VALUE OF REWARDS
                    r=reweighting * advantageEst
                    print ("ADVANTAGE EST: " + str(advantageEst))
                    print("REWEIGHTING: " + str(reweighting))
                    print("REWARD:" + str(reward))
                   # print ("EPSILON: " + str(epsilon))
                    if reweighting  <= 1 -  epsilon and  advantageEst < 0:
                        rClip= (1 -  epsilon) * advantageEst
                    elif reweighting >= 1 +  epsilon and advantageEst > 0:
                        rClip= (1 +  epsilon) * advantageEst
                    else:
                        rClip= reweighting * advantageEst               
                    r = min(r, rClip )
                    print ("VALUE OF r:" + str(r) + ", VALUE OF rClip: " + str(rClip))
                    #self.log("VALUE OF r: %.2f" % r)
            except:
                print ("**ERROR IN ALGORITHM", sys.exc_info()[0])
                
                
           # self.log("REWARD: %.2f" % reward)
        
        #self.log('REWARD: ' + str(reward))
        # self.log('REWARD: %.2f' % str(reward))
        # self.log('High, %.2f' % self.datahigh[0])
        # Check if an order is pending ... if yes, we cannot send a 2nd one
        if self.order:
            return

        # Check if we are in the market
       # print("REWARD: " + str(reward))
        
        if str(wasBought.name) == 'YES':
          if oldReward > reward:
              if dropCount < 3:
                  dropCount += 1
              else:
                  dropCount=0
                  entSellAmount.delete(0,END)
                  entSellAmount.insert(END,float(netWorth))
                  lblSell.pack()
                  entSellAmount.pack()
                  rbYesSell.pack()
                  rbNoSell.pack()
                        
        if not self.position:

            # Not yet ... we MIGHT BUY if ...
            if self.dataclose[0] < self.dataclose[-1]:
                    # current close less than previous close

                    if self.dataclose[-1] < self.dataclose[-2]:
                        # previous close less than the previous close

                        # BUY, BUY, BUY!!! (with default parameters)
                        if (str(gotStockDataFrom.name) == 'CHECKHISTORY'):
                          self.log('BUY CREATE, %.2f' % self.dataclose[0])

                        # Keep track of the created order to avoid a 2nd order
                          self.order = self.buy()
                        elif str(wasBought.name) == 'NO':
                              lblBuy.place(x=500,y=1100)
                              entBuyAmount.place(x=500,y=1150)
                              btnBuy.place(x=500,y=1200)
  

       # Already in the market ... we might sell
        else:
            print("SELLING:")
            if (str(gotStockDataFrom.name) == 'CHECKHISTORY'):
             if len(self) >= (self.bar_executed + 5):
                 # SELL, SELL, SELL!!! (with all possible default parameters)
                 self.log('SELL CREATE, %.2f' % self.dataclose[0])

                 # Keep track of the created order to avoid a 2nd order
                 self.order = self.sell() 

                
        

 


def button_click():
    txtStockInfo.delete('1.0',END)
    stockSymbolString=txtStockSymbol.get().upper()
    lblStockHistory['text']="Stock history for " + stockSymbolString
    print ("YOU CLICKED FOR SYMBOL " + stockSymbolString)
    try:
        portfolioValue=float(txtPortfolio.get())
    except:
        portfolioValue=0
    global stockInfo
    global balance
    stockInfo=""
    cerebro = bt.Cerebro()
    global plt
    global closeList
    global closeValues
    global btnSavePortfolioFile
    global gotStockDataFrom
    global currentPortfolioDate
    global numberOfShares
    global currentPrice
    global trading
    global netWorth
    global profit
    global tradingAmount
    global portfolioUpdated
   # print ("CURRENT PORTFOLIO DATE: " + str(currentPortfolioDate))
    itsFrom=None
    todaysDate=None
   
    print("YOUR DATA SOURCE: " + gotStockDataFrom.name)
   # print( str(gotStockDataFrom.name) == 'CHECKHISTORY')
    #global portfolioValue
  #  print ('YOUR CURRENT PORTFOLIO: %.2f' % portfolioValue )
  #  print ('NUMBER OF SHARES: ' + str(numberOfShares))
 #   print ('CURRENT PRICE: ' + str(currentPrice))
  #  print ('NET WORTH: ' + str(netWorth))
    closeList=[]
    closeValues=[]
    profitValues=[]
    itsFrom=datetime.datetime.now()
    

    # Add a strategy
    cerebro.addstrategy(TestStrategy)

    # Datas are in a subfolder of the samples. Need to find where the script is
    # because it could have been called from anywhere
    modpath = os.path.dirname(os.path.abspath(sys.argv[0]))
   #datapath = os.path.join(modpath, './datas/orcl-1995-2014.csv')

    # Create a Data Feed
    todaysDate=datetime.datetime.now()
    lastMonth=todaysDate + datetime.timedelta(days=-30)
    if (str(gotStockDataFrom.name) == 'CHECKHISTORY'):  
        itsFrom=lastMonth
    else:
        print(str(currentPortfolioDate)[:10])
        try:
            itsFrom= datetime.datetime.strptime(str(currentPortfolioDate)[:10],"%m/%d/%Y")
        except:
             itsFrom= datetime.datetime.strptime(str(currentPortfolioDate)[:10],"%Y-%m-%d")
    print ("IT'S FROM " + str(itsFrom))
  #  try:
    print ("GETTING DATA...")
    data = bt.feeds.YahooFinanceData(
        #dataname=datapath,
        dataname=  stockSymbolString ,
        # Do not pass values before this date
        fromdate=itsFrom,
        # Do not pass values before this date
        todate=todaysDate  + datetime.timedelta(days=1),
        # Do not pass values after this date
        reverse=False)
    print ("IT'S FROM " + str(itsFrom) + ", CURRENT PORTFOLIO DATE: " + str(currentPortfolioDate) + " TODAY'S DATE: " + str(todaysDate))
    if (itsFrom == todaysDate):
        txtStockInfo.insert(tk.END, "**YOU BOUGHT SHARES TODAY!")
        return
    # Add the Data Feed to Cerebro
    print('ADDING DATA...')
    cerebro.adddata(data)

    # Set our desired cash start
    print("SETTING CASH...")
    cerebro.broker.setcash(portfolioValue)
    balance=portfolioValue
    # Print out the starting conditions
    print("TO START PORFOLIO...")
    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())
    stockInfo += 'Starting Portfolio Value: %.2f' % cerebro.broker.getvalue() + "\n"
    # Run over everything
    cerebro.run()
    
    # Print out the final result
    print('Final Portfolio Value: %.2f' % cerebro.broker.getvalue())    # Plot the result
    stockInfo += 'Final Portfolio Value: %.2f' % cerebro.broker.getvalue()
    
    txtStockInfo.insert(tk.END, stockInfo)
    btnSavePortfolioFile["state"]="normal"
    btnSavePortfolioFile["bg"]='yellow'
    finalPortfolioValue=cerebro.broker.getvalue()
    #cerebro.plot(iplot= False)
    plt.suptitle("STOCK CLOSING DATA FOR " + stockSymbolString + " " + str(itsFrom.strftime("%b-%d-%y")) + " - " + str(todaysDate.strftime("%b-%d-%y"))) #
    plt.plot(closeList, closeValues)  
    plt.grid(True)
    plt.show()
    gotStockDataFrom=stockDataSource.CHECKHISTORY     
   # except:
   #    if txtStockInfo.get("1.0",END) == "": txtStockInfo.insert(tk.END, "**NO STOCK SYMBOL FOR %s" % stockSymbolString)       
        
def save_portfolio():
     global portfolioList
     global os
     global portfolioRecords
     stockSymbolString=txtStockSymbol.get().upper()
     todaysDate=datetime.datetime.now().strftime('%Y-%m-%d')
     finalPortfolioValue=float(txtPortfolio.get())
     portfolioFileName=stockSymbolString + ".csv"
     if path.exists('./portfolio/' + portfolioFileName) == False:    
      fields=['Symbol','Updated','Balance', 'Transaction', 'NumberOfShares', 'CurrentPrice', 'TradingAmount', 'Net Worth', 'Profit']
     csvRows=[stockSymbolString, todaysDate, finalPortfolioValue,'-','0.0','0.0','0.0','0.0','0.0']      
     with open('./portfolio/' + portfolioFileName, 'a') as portfolioFileName:
         csvWriter=csv.writer(portfolioFileName)
         csvWriter.writerow(fields)
         csvWriter.writerow(csvRows)

     portfolioList.insert(END, stockSymbolString + '.csv')

def select_portfolio():
    global portfolioList
    global txtPortfolio
    global txtStockSymbol
    global currentPortfolioDate
    global gotStockDataFrom
    global balance
    global numberOfShares
    global currentPrice
    global tradingAmount
    global netWorth
    global profit
    global portfolioUpdated
    global buyingChoice
    global wasBought
    closeList=[]
    closeValues=[]
    profitValues=[]
    todaysDate=datetime.datetime.now()
    portfolioRows=""
    currentPortfolioData={}
    stockSymbolString=portfolioList.get( portfolioList.curselection())
    buyingChoice=False
    print("CURRENT PORTFOLIO DATE: " + str(currentPortfolioDate))
    print ("you selected " + stockSymbolString )
    print (stockSymbolString[:-4])
    wasBought=thisStockBought.NO
    with open('./portfolio/' + stockSymbolString, 'r') as portfolioFile:
        reader=csv.reader(portfolioFile)
        rowCount=0
        for row in reader:
            portfolioSubrow=""
            for item in range(len(row)):
                print(row[item])
                if rowCount == 0:
                    portfolioSubrow += row[item].center(9) + " | "
                else:
                        if item == 2:
                            if row[item] != '':
                             txtPortfolio.delete(0,END)
                             txtPortfolio.insert(END, row[item])
                             balance=row[item]
                             balance=round(float(balance),2)
                        if item == 1:
                              if str(row[item]) != '': 
                                  currentPortfolioDate=str(row[item])
                              if rowCount > 2:
                                  if str(currentPortfolioDate) != '' and str(currentPortfolioDate) not in closeList:
                                   closeList.append(str(currentPortfolioDate))                            
                       # try:
                          #     currentPortfolioDate=datetime.datetime.strptime(row[item],'%m/%d/%Y')
                        #       print ("DATE: " + str(currentPortfolioDate))
                              
                        #except:
                          #     pass
                        if item == 3:
                            if row[item] == 'BUY':
                                wasBought=thisStockBought.YES
                            elif row[item] == 'SELL':
                                wasBought=thisStockBought.NO
                        
                        if item >= 5:
                            portfolioSubrow += row[item].center(22)
                            if item == 5: 
                                currentPrice=row[item]
                                if rowCount > 2:
                                 try:   
                                  closeValues.append(float(currentPrice))
                                  print("CLOSING PRICE: " + str(currentPrice))
                                 except:
                                     pass
                            if item == 6: tradingAmount=row[item]
                            if item == 7: netWorth=row[item]
                            if item == 8: 
                                if rowCount >2:
                                 try:
                                  profit=row[item] 
                                  profitValues.append(float(profit))
                                 except:
                                     pass
                            
                        elif item == 4:
                            try:
                             fl=round(float(row[item]),2)
                             portfolioSubrow += str(fl).center(22) 
                             numberOfShares= row[item]
                            except:
                                pass
                        else:
                            portfolioSubrow += row[item].center(10)
 

            if rowCount == 0:
                    portfolioSubrow += "\n"
                    portfolioSubrow+=90 * "="
            portfolioSubrow += "\n"
            rowCount+=1
            portfolioRows += portfolioSubrow
            
    #print(str(closeList[len(closeList)-1]))
    #currentPortfolioDate=closeList[len(closeList)-1]
    txtPortfolioData.delete('1.0',END)
    txtPortfolioData.insert(END, portfolioRows)   
    txtStockSymbol.delete(0,END)
    txtStockSymbol.insert(END,stockSymbolString[:-4]) 
    gotStockDataFrom=stockDataSource.PORTFOLIOFILE
    print ("TRADING AMOUNT: " + str(tradingAmount))
    print ("CURRENT PRICE: " + str(currentPrice))
    
    print ("CURENT PORTFOLIO DATE: " + str(currentPortfolioDate))
    portFile='./portfolio/' + stockSymbolString
    modTime=time.strftime('%m/%d/%Y', time.localtime(os.path.getmtime(portFile)))
    print (modTime)
    print (todaysDate.strftime('%m/%d/%Y'))
    print (closeList)
    print (closeValues)
    print (profitValues)
    if (modTime != todaysDate.strftime('%m/%d/%Y')):
        button_click()
    else:
        plt.plot(closeList, closeValues)
        plt.plot(closeList, profitValues)
        plt.grid(True)
        plt.show()
    #    if str(wasBought.name) == 'YES':
    #        lblSell.pack()
    #        entSellAmount.pack()
    #        rbYesSell.pack()
    #        rbNoSell.pack()
            

    gotStockDataFrom=stockDataSource.CHECKHISTORY 

    
def buy_shares():
    global currentPortfolioDate
    global txtStockSymbol
    global balance
    global lastClosingPrice
    global buyAmount
    global buying
    global lblBuy
    global entBuyAmount
    global btnBuy
    global numberOfShares
    fields=[]
    csvRows=[]
    activityContents=""

    buyAmount=entBuyAmount.get()
    if float(buyAmount)==0:
        lblBuy.destroy()
        entBuyAmount.destroy()
        btnBuy.destroy() 
        return
    
    print ("AMOUNT OF PURCHASE: " + buyAmount)
    numberOfShares=float(buyAmount)/float(lastClosingPrice)
   # numberOfShare="%.2f" % numberOfShares
   # print (numberOfShares)
    print ("YOU BOUGHT " + str(numberOfShares))
    balance -= float(buyAmount)
    print ("YOUR BALANCE: " + str(balance))
    netWorth=balance + numberOfShares * lastClosingPrice
    profit=netWorth-balance
    txtPortfolio.delete(0,END)
    txtPortfolio.insert(END,float(balance))
    stockSymbolString=txtStockSymbol.get().upper()
    todaysDate=datetime.datetime.now().strftime('%m/%d/%Y')
    finalPortfolioValue=float(txtPortfolio.get())
    portfolioFileName=stockSymbolString + ".csv"
    if path.exists('./portfolio/' + portfolioFileName) == False:    
      fields=['Symbol','Updated','Balance', 'Transaction', 'NumberOfShares', 'CurrentPrice', 'TradingAmount', 'Net Worth', 'Profit']
    csvRows=[stockSymbolString, todaysDate, finalPortfolioValue,'BUY',numberOfShares,lastClosingPrice,buyAmount,netWorth,profit]      
    with open('./portfolio/' + portfolioFileName, 'a') as portfolioFile:
         csvWriter=csv.writer(portfolioFile)
         csvWriter.writerow(csvRows)    

    
    txtPortfolioData.delete('1.0',END)
    portfolioText=""

    gotStockDataFrom=stockDataSource.PORTFOLIOFILE
    txtStockSymbol.delete(0,END)
    txtStockSymbol.insert(END,stockSymbolString[:-4])
    txtPortfolio.delete(0,END)
    txtPortfolio.insert(END,balance) 

    lblBuy.destroy()
    entBuyAmount.destroy()
    btnBuy.destroy()

    
    
def sell_Stock():
    global balance
    global netWorth
    global profit
    global currentPrice
    global numberOfShares
    global portfolioFileName
    global stockSymbolString
    global todaysDate
    global var
    todaysDate=datetime.datetime.now()
    todaysDate=str(todaysDate.strftime('%m/%d/%Y'))
    if var.get() == 1:
        balance += float(numberOfShares) * float(currentPrice)
        balance=round(balance,2)
        numberOfShares=0
        portfolioFileName=stockSymbolString + '.csv'
        csvRows=[stockSymbolString, todaysDate, balance,'SELL',numberOfShares,lastClosingPrice,buyAmount,netWorth,profit]      
        with open('./portfolio/' + portfolioFileName, 'a') as portfolioFile:
             csvWriter=csv.writer(portfolioFile)
             csvWriter.writerow(csvRows)
    lblSell.destroy()
    entSellAmount.destroy()
    rbYesSell.destroy()
    rbNoSell.destroy()
    txtStockInfo.delete('1.0',END)
             
    
def find_stock_symbol():
    global dctSymbols
    if entFindSymbol.get() == "": return
    lstSymbols.delete(0,END)
    srchString=entFindSymbol.get()
    itemCount=0
    for key,value in dctSymbols.items():
        if srchString.upper() in value.upper() or srchString.upper() in key.upper():
            print(value)
            lstSymbols.insert(itemCount,key.ljust(9) + "|" + value)
            itemCount +=1
            
def reset_symbol_list():
 global dctSymbols
 lstSymbols.delete(0,END)
 with open('StockSymbols.csv', 'r') as symbolsFile:
  reader=csv.reader(symbolsFile)
  rowCount=0
  for row in reader:
      symbolItem=''
      if rowCount == 0:
          rowCount +=1
          continue
      for symbolColumn in range(2):
          symbolItem += row[symbolColumn].ljust(9) + "|"
      dctSymbols[row[0]]=row[1]
      lstSymbols.insert(rowCount,symbolItem)
      rowCount+=1   
      
def select_your_symbol():
    symbolItem=lstSymbols.get(lstSymbols.curselection())
    pipePos=symbolItem.find("|")
    symbolResult=symbolItem[0:pipePos].rstrip()
    txtStockSymbol.delete(0, END)
    txtStockSymbol.insert(END, symbolResult)
    
    
    
    
stockInfo=""
root = tk.Tk()
root.title("Stock Trading")
root.geometry("1200x1300")  
root.configure(bg='#55bb22')
lblSearchSymbol=tk.Label(root,text="Search a symbol",font='Arial 10 bold',bg='#55bb22')
entFindSymbol=tk.Entry(root, width="10", font='Arial 20 bold')
lstSymbols=Listbox(root, height=20, width="22",font='Arial 10 bold', bg="#aaeeff")
lstSymbols.bind("<<ListboxSelect>>", lambda x:select_your_symbol())
dctSymbols={}
reset_symbol_list()
       
lblSearchSymbol.place(x=40,y=10)
entFindSymbol.place(x=40, y=32)
btnFindSymbol=tk.Button(root, text="FIND", width=22, command=find_stock_symbol)
btnFindSymbol.place(x=40,y=88 )
lstSymbols.place(x=40, y=130)
btnResetSymbols=tk.Button(root, text="RESET", width=22, bg="dark green", fg="white", command=reset_symbol_list)
btnResetSymbols.place(x=40,y=650)
lblEnterPortfolio=tk.Label(root, text="ENTER YOUR PORTFOLIO AMOUNT:", font='Arial 10 bold', bg='#55bb22')
lblEnterPortfolio.pack()
txtPortfolio=tk.Entry(root, font='Arial 20 bold')
txtPortfolio.pack()
lblEnterSymbol=tk.Label(root, text="ENTER A STOCK SYMBOL:", font='Arial 10 bold', bg='#55bb22')
currentStep=0
baseline=0
gamma=0.999
Gt=0
oldReward=0
epsilon=0.4
Return=0
reweighting=0
rClip=0
gotStockDataFrom=0
currentPortfolioDate=None
balance=0
portfolioRecords=[]
purchaseAmount=0
lastClosingPrice=0
buyAmount=0
buyingChoice=False
numberOfShares=0
netWorth=0
profit=0
balance=0
buyAmount=0
portfolioUpdated=False
dropCount=0
lblEnterSymbol.pack()
txtStockSymbol=tk.Entry(root, font='Arial 20 bold')
txtStockSymbol.pack()
gotStockDataFrom=stockDataSource.CHECKHISTORY
wasBought=thisStockBought.NO
btnStockSymbol=tk.Button(root, text="GET STOCK HISTORY INFORMATION", bg="dark gray", command=button_click)
btnStockSymbol.pack()
lblStockHistory=tk.Label(root, text="Stock history" , bg='#55bb22', font='Arial 11 bold')
lblStockHistory.pack()
txtStockInfo=tk.Text(root, height=10, width=50, font='Arial 11 bold' )
txtStockInfo.pack()
btnSavePortfolioFile=tk.Button(root, text="SAVE CURRENT STOCK", bg="gray", state="disabled", command=save_portfolio)

btnSavePortfolioFile.pack()
lblPortfolioFiles=tk.Label(root,text="Your portfolio files:", bg='#55bb22', font='Arial 11 bold')
lblPortfolioFiles.pack()
portfolioList=Listbox(root, height="5")
portfolioList.bind("<<ListboxSelect>>", lambda x: select_portfolio())

for i in range(len(os.listdir('./portfolio'))):
    portfolioList.insert(i,os.listdir('./portfolio')[i])
portfolioList.pack()
#lblActivityData=tk.Label(root,text="Activity data:",bg='#55bb22', font='Arial 11 bold' )
#lblActivityData.place(x=80, y=850)
lblPortfolioData=tk.Label(root,text="Current portfolio data:" , bg='#55bb22', font='Arial 11 bold')
lblPortfolioData.pack()
#txtActivityData=tk.Text(root,height=8, width=60, font='Times 8 bold',bg='beige', foreground='#885511')
#txtActivityData.place(x=80,y=890)
txtPortfolioData=tk.Text(root, height=8, width=100, font='Times 10 bold',bg='beige', foreground='#885511')
txtPortfolioData.pack()
lblBuy=tk.Label(root, text="Buy shares? (enter a dollar figure, 0='no')", bg='#55bb22', font='Arial 11 bold')
lblBuy.pack_forget()
entBuyAmount=tk.Entry(root, font='Arial 20 bold', width=10)
entBuyAmount.pack_forget()
btnBuy=tk.Button(root, text="BUY CURRENT STOCK", bg="dark green", foreground="white", command=buy_shares)
btnBuy.pack_forget()
lblSell=tk.Label(root, text="Ready to sell for this amount?", bg='#55bb22', font='Arial 11 bold')
lblSell.pack_forget()
entSellAmount=tk.Entry(root, font='Arial 20 bold', width=10 )
entSellAmount.pack_forget()
var = IntVar()
rbYesSell=Radiobutton(root, text="Yes",variable=var, value=1, command=sell_Stock, bg='#55bb22', font='Arial 11 bold')
rbYesSell.pack_forget()
rbNoSell=Radiobutton(root,text="No", variable=var, value=2, command=sell_Stock, bg='#55bb22', font='Arial 11 bold')
rbNoSell.pack_forget()
root.update()
tk.mainloop()

